import React, { useState, useEffect } from "react";
import { Line } from "react-chartjs-2";
import prepareData from "./ChartDataPreparer";
import formatData from "./ChartDataFormatter";
import options from "./ChartOptions";
import { useSelector } from "react-redux";
import "chart.js/auto";
import { consolidateData } from "./consolidationLogic"; // Nouveau

const ChartComponent = () => {
  const [chartData, setChartData] = useState(null);
  const [tableDataPages, setTableDataPages] = useState(null);
  const [tableDataQuery, setTableDataQuery] = useState(null);

  const filteredData = useSelector((state) => state.filteredData);
  const startWeek = useSelector((state) => state.filter.startWeek);
  const endWeek = useSelector((state) => state.filter.endWeek);

  useEffect(() => {
    const preparedData = prepareData(filteredData.data, startWeek, endWeek);
    const formattedData = formatData(preparedData);
    setChartData(formattedData);
    const newTableDataPages = consolidateData(preparedData, "Pages");
    const newTableDataQuery = consolidateData(preparedData, "Query");

    setTableDataPages(newTableDataPages);
    setTableDataQuery(newTableDataQuery);
    console.log(tableDataPages);
    console.log(tableDataQuery);
  }, [filteredData, tableDataPages, tableDataQuery, startWeek, endWeek]);

  if (!chartData) {
    return <div>Loading...</div>;
  }

  return <Line data={chartData} options={options} />;
};

export default ChartComponent;
