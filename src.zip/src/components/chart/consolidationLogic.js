export const consolidateData = (data, keyField) => {
  const consolidated = [];
  data.forEach((row) => {
    const key = row[keyField];
    if (!consolidated[key]) {
      consolidated[key] = {
        Clicks: 0,
        Impressions: 0,
      };
    }
    consolidated[key].Clicks += row.Clicks;
    consolidated[key].Impressions += row.Impressions;
  });
  return consolidated;
};
